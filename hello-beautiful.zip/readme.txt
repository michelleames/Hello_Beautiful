=== Hello Beautiful ===
Contributors: michelleames
Donate link: https://worksbymichelle.com/
Stable tag: 1.1
Tested up to: 5.5.1
Requires at least: 4.6
Requires PHP: 7.1
License: GPLv3
License URI: https://opensource.org/licenses/GPL-3.0

This is not just a plugin, it's a reminder of how awesome you are, how talented you are, and how much you are valued.

== Description ==

This is not just a plugin, it tells you how amazing you are!

