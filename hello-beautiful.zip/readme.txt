=== Hello Beautiful ===
Contributors: michelle frechette
Stable tag: 1.1
Tested up to: 5.2
Requires at least: 4.6

This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong.

== Description ==

This is not just a plugin, it tells you how amazing you are!